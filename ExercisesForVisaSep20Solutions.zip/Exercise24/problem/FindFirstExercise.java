public class FindFirstExercise {

	public static void main(String[] args) {
		


	}

}
