package solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class FindFirstExercise {

	public static void main(String[] args) {
		String[] temp = {"this","is","a","small","arrays","of","words"};
		List<String> words = new ArrayList<>(Arrays.asList(temp));
		
		Optional<String> result = words.stream().map(s->s.toUpperCase()).filter(s->s.length()>3).filter(s->s.length()%3==0).findFirst();
		
		if(result.isPresent()) {
			System.out.println(result.get());
		}else {
			System.out.println("no such word");
		}

	}

}
