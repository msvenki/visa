package com.training.service;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import com.training.dal.ProductDAO;
import com.training.dal.ProductDAOInMemImpl;
import com.training.domain.Product;



public class ProductServiceImplTestWithMock {

	@Test
	public void addNewproduct_Retuns_Valid_ID_When_ArgValue_GTEQ_Min_Value() {
		
		//Arrange
		Product toBeCreated = new Product("test", 10000, 1);
		ProductServiceImpl service = new ProductServiceImpl();
		Product created = new Product("test", 10000, 1);
		created.setId(1);
		
		ProductDAO mockDAO = Mockito.mock(ProductDAO.class);
		//System.out.println(mockDAO.getClass().getName());
		Mockito.when(mockDAO.save(toBeCreated)).thenReturn(created);
		
		service.setDao(mockDAO);
		//Act
		int id = service.addNewProduct(toBeCreated);
		//Assert
		Assert.assertTrue(id > 0);
		
	}

}
