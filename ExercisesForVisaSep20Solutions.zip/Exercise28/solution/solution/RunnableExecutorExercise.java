package solution;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RunnableExecutorExercise {

	public static void main(String[] args) {
		ExecutorService pool = Executors.newFixedThreadPool(2);
		PrimeCounter c1 = new PrimeCounter(100, 10000);
		PrimeCounter c2 = new PrimeCounter(10001, 100000);
		
		pool.execute(c1);
		pool.execute(c2);
		
		pool.shutdown();

	}

}
