package solution;


public class PrimeCounter implements Runnable {

	int start, stop;

	public PrimeCounter(int start, int stop) {

		this.start = start;
		this.stop = stop;
	}

	public void run() {
		int count = 0;

		for (int num = start; num <= stop; num++) {
			boolean flag = false;
			for (int i = 2; i <= num / 2; ++i) {
				// condition for nonprime number
				if (num % i == 0) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				count++;
			}
		}
		
		System.out.println("There are "+count+" primes between "+start+" and "+stop);
	}

}
