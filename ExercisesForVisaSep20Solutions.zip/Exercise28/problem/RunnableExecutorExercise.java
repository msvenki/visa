
public class RunnableExecutorExercise {

	public static void main(String[] args) {
		

	}

}
