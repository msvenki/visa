package interestcalculators;

public class SimpleInterestCalculator {
	
	
	public double calculateInterest(double principal,double rate,int time) {
		return (principal * time * rate)/100;
	}

}
