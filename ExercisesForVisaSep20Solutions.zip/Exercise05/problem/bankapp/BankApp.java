package bankapp;

import solution.interestcalculators.InterestCalculator;
import solution.interestcalculators.SimpleInterestCalculator;
import solution.loanmanagement.LoanProcessor;

public class BankApp {

	public static void main(String[] args) {
		
		InterestCalculator interestCalculator = new SimpleInterestCalculator();
		
		LoanProcessor processor = new LoanProcessor(interestCalculator);
		
		processor.generateEstimate("Pradeep LN", 1000000, 6, 7);

	}

}
