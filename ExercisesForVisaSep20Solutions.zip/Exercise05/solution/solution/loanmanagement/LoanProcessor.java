package solution.loanmanagement;

import solution.interestcalculators.InterestCalculator;

public class LoanProcessor {
	
	InterestCalculator interestCalculator;

	public LoanProcessor(InterestCalculator interestCalculator) {
		super();
		this.interestCalculator = interestCalculator;
	}
	
	public void generateEstimate(String applicantName, double principal, double rate, int time) {
		System.out.println("Processing Loan Estimation");
		
		double interestCost = interestCalculator.calculateInterest(principal, rate, time);
		
		System.out.println("Loan estimate for "+applicantName);
		System.out.println("Estimated Interest Cost is : "+interestCost);
	}
	

}
