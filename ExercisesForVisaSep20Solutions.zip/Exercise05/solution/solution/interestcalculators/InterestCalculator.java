package solution.interestcalculators;

public interface InterestCalculator {

	double calculateInterest(double principal, double rate, int time);

}