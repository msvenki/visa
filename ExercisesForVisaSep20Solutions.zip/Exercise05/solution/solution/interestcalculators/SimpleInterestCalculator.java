package solution.interestcalculators;

public class SimpleInterestCalculator implements InterestCalculator {
	
	
	@Override
	public double calculateInterest(double principal,double rate,int time) {
		return (principal * time * rate)/100;
	}

}
