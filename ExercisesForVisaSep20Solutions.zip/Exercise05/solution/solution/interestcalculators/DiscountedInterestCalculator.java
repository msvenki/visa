package solution.interestcalculators;

public class DiscountedInterestCalculator implements InterestCalculator {
	
	public double calculateInterest(double principal,double rate,int time) {
		
		if(time >= 5) {
			rate = rate - (rate * 0.1);
		}
		
		return (principal * time * rate)/100;
	}

}
