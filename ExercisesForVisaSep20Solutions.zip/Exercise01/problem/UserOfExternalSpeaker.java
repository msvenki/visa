import solution.ExternalSpeaker;

public class UserOfExternalSpeaker {
	
	public void playMusic() {
		ExternalSpeaker speaker = new ExternalSpeaker();
		
	}

}
