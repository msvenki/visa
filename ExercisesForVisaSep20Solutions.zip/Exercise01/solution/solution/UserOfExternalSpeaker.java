package solution;


public class UserOfExternalSpeaker {
	
	public void playMusic() {
		ExternalSpeaker speaker = new ExternalSpeaker();
		
	}

}
