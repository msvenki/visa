package solution;

public class ExternalSpeaker {
	
	private int speakerVolume = 5; // Valid range of values from 0 to 10
	
	private int batteryLevel ; // Valid range of values from 1 to 100
	
	private void makeBeepSoundToIndicateLowBattery() {
		//Some implementation to make beep sound
	}
	
	public void on() {
		if(batteryLevel < 10) {
			makeBeepSoundToIndicateLowBattery();
		}
		//Some implementation to switch on
	}
	
	public void off() {
		//Some implementation to switch off
	}
	
	public void volumeUp() {
		speakerVolume++;
		//Some implementation to play louder
	}
	
	public void volumeDown() {
		speakerVolume--;
		//Some implementation to play less louder
	}
	

}
