
public class JustAClass {

}
