public class BasicLambdaSyntaxExercise {

	public static void main(String[] args) {
		

	}

}
