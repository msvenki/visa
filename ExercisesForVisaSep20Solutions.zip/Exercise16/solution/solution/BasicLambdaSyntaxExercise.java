package solution;

import java.util.Arrays;

public class BasicLambdaSyntaxExercise {

	public static void main(String[] args) {
		String[] strings = { "this", "is", "a", "small", "array", "of", "words", "eh?" };

		System.out.println("Before Sorting\n" + Arrays.asList(strings));
		Arrays.sort(strings);
		System.out.println("After Sorting Alphabetically\n" + Arrays.asList(strings));
		Arrays.sort(strings, (s1, s2) -> s1.length() - s2.length());
		System.out.println("After Sorting By Length\n" + Arrays.asList(strings));
		Arrays.sort(strings, (s1, s2) -> s2.length() - s1.length());
		System.out.println("After Sorting By Reverse Length\n" + Arrays.asList(strings));
		Arrays.sort(strings, (s1, s2) -> {
			if (s1.contains("e") && !s2.contains("e")) {
				return -1;
			} else if (s2.contains("e") && !s1.contains("e")) {
				return 1;
			} else {
				return 0;
			}
		});
		System.out.println("After Sorting By e\n" + Arrays.asList(strings));
	}

}
