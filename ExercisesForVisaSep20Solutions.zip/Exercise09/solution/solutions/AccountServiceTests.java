package solutions;

import static org.junit.Assert.*;

import org.junit.Test;

import com.bank.dal.AccountDAO;
import com.bank.dal.AccountDAOInMemoryImpl;
import com.bank.domain.Account;
import com.bank.service.AccountService;
import com.bank.service.InsufficientBalanceException;

public class AccountServiceTests {

	@Test
	public void createNewAccount_Returns_Valid_Id_When_Balanace_GTEQ_MinBalance() {
		//Arrange
		AccountService service = new AccountService();
		
		//Act
	
		int id = service.createNewAccount("SA", 10001);
		//Assert
		assertTrue(id > 0);
	}

	@Test
	public void createNewAccount_Returns_Zero_When_Balanace_LT_MinBalance() {
		//Arrange
		AccountService service = new AccountService();
		//Act
	
		int id = service.createNewAccount("SA", 9999);
		//Assert
		assertTrue(id == 0);
	}
	
	@Test
	public void withdraw_Reduces_Balance_When_Sufficient_Balanace() throws InsufficientBalanceException {
		//Arrange
		AccountService service = new AccountService();
	
		Account anAccount = new Account();
		anAccount.setType("SA");
		anAccount.setBalance(100000);
		
		AccountDAO dao = new AccountDAOInMemoryImpl();
		int id = dao.create(anAccount);
		service.setDao(dao);
		//Act
		
		service.withdraw(id, 1000);
		
		//Assert
		assertEquals(99000, anAccount.getBalance(), 0.1);
	}
	
	@Test(expected = InsufficientBalanceException.class)
	public void withdraw_Throws_When_Insufficient_Balanace() throws InsufficientBalanceException {
		//Arrange
		AccountService service = new AccountService();
	
		Account anAccount = new Account();
		anAccount.setType("SA");
		anAccount.setBalance(100000);
		
		AccountDAO dao = new AccountDAOInMemoryImpl();
		int id = dao.create(anAccount);
		service.setDao(dao);
		//Act
		
		service.withdraw(id, 100001);
		
		//Assert
		
	}
	
	@Test
	public void deposit_Increases_Balance()  {
		//Arrange
		AccountService service = new AccountService();
	
		Account anAccount = new Account();
		anAccount.setType("SA");
		anAccount.setBalance(100000);
		
		AccountDAO dao = new AccountDAOInMemoryImpl();
		int id = dao.create(anAccount);
		service.setDao(dao);
		//Act
		
		service.deposit(id, 1000);
		
		//Assert
		assertEquals(101000, anAccount.getBalance(), 0.1);
	}
}
