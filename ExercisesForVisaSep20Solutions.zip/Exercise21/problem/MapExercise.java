public class MapExercise {

	public static void main(String[] args) {
		


	}

}
