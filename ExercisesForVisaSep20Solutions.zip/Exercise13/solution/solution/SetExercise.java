package solution;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class SetExercise {

	public static void main(String[] args) {
		Scanner keyBoard = new Scanner(System.in);

		Set<String> words = new HashSet<>();

		while (true) {
			System.out.println("Enter a word: ");
			String aWord = keyBoard.nextLine();
			if (words.size() >= 7 && aWord.equalsIgnoreCase("quit")) {
				break;
			}
			boolean unique = words.add(aWord);
			if(!unique) {
				System.out.println("Duplicate detected!");
			}
		}
		
		System.out.println("All elements: ");
		for(String s : words) {
			System.out.println(s);
		}

	}

}
