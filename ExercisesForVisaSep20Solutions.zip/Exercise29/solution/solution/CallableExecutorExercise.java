package solution;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableExecutorExercise {

	public static void main(String[] args) throws Exception {
		ExecutorService pool = Executors.newFixedThreadPool(2);
		PrimeCounter c1 = new PrimeCounter(100, 10000);
		PrimeCounter c2 = new PrimeCounter(10001, 100000);
		
		Future<Integer> r1 = pool.submit(c1);
		Future<Integer> r2 = pool.submit(c2);
		
		System.out.println(r1.get());
		System.out.println(r2.get());
		
		pool.shutdown();

	}

}
