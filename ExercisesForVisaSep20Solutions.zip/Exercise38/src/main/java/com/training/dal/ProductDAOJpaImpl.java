package com.training.dal;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.training.domain.Product;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class ProductDAOJpaImpl implements ProductDAO {
	@Autowired
	EntityManager em;

	@Override
	public Product save(Product toBeSaved) {
		em.persist(toBeSaved);
		return toBeSaved;
	}

	@Override
	public Product findById(int id) {
		Product p = em.find(Product.class, id);
		return p;
	}

	@Override
	public List<Product> findAll() {
		Query q = em.createQuery("SeLeCt p FROM Product as p");
		List<Product> all = q.getResultList();
		return all;
	}

	@Override
	public void deleteById(int id) {
		Product p = em.find(Product.class, id);
		em.remove(p);

	}

}
