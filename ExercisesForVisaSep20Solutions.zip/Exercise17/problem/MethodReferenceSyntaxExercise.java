public class MethodReferenceSyntaxExercise {

	public static void main(String[] args) {
		

	}

}
