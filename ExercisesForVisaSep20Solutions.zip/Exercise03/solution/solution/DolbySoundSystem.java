package solution;

public class DolbySoundSystem {
	
	public void playSound() {
		System.out.println("[[[[[[ Playing 5.1 Sound ]]]]]]");
	}

}
