package solution;

public class TV4K extends TV {
	
	private DolbySoundSystem soundSystem = new DolbySoundSystem();
	
	@Override
	public void playSound() {
		soundSystem.playSound();
	}

	public void on() {
		System.out.println("<<<<<<Switching on 4K TV....>>>>>>");
	}
	
	public void off() {
		System.out.println("<<<<<<Switching off 4K TV....>>>>>>");
	}
	
	
	
}
