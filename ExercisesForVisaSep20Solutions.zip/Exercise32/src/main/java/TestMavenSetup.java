
public class TestMavenSetup {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Maven Set Up Working");
		}catch (ClassNotFoundException e) {
			System.out.println("Maven Set Up Seems to have FAILED!!");
			System.out.println("Try doing a Maven update!!");
			System.out.println("If it still doesn't work, you need to check if you need settings.xml configuration for proxy");
		}

	}

}
