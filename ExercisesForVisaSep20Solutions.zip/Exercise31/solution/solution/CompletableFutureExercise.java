package solution;

import java.util.concurrent.CompletableFuture;

public class CompletableFutureExercise {

	public static void main(String[] args) {
		PrimeCounter counter = new PrimeCounter(100, 1000);
		CompletableFuture.supplyAsync(counter::count).thenAccept(CompletableFutureExercise::displayResult);

	}
	
	public static void displayResult(Integer num) {
		System.out.println("There are "+num+" number of primes in that range.");
	}

}
