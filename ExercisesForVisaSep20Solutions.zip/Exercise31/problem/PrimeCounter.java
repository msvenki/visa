public class PrimeCounter {

	int start, stop;

	public PrimeCounter(int start, int stop) {

		this.start = start;
		this.stop = stop;
	}

	public int count() {
		int count = 0;

		for (int num = start; num <= stop; num++) {
			boolean flag = false;
			for (int i = 2; i <= num / 2; ++i) {
				// condition for nonprime number
				if (num % i == 0) {
					flag = true;
					break;
				}
			}
			if (!flag) {
				count++;
			}
		}
		
		return count;
	}

}
