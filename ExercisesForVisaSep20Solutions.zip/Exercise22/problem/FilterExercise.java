public class FilterExercise {

	public static void main(String[] args) {
		


	}

}
