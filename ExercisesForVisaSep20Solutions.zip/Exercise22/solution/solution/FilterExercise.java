package solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FilterExercise {

	public static void main(String[] args) {
		
		String[] temp = {"this","is","a","small","array","of","words"};
		List<String> words = new ArrayList<>(Arrays.asList(temp));
		
		List<String> shortWords =words.stream().filter(s -> s.length() < 4).collect(Collectors.toList());
		List<String> wordsWithB =words.stream().filter(s -> s.contains("b")).collect(Collectors.toList());
		List<String> evenLengthWords =words.stream().filter(s -> (s.length() % 2) == 0).collect(Collectors.toList());


	}

}
