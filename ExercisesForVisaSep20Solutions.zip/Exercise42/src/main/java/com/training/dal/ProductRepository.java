package com.training.dal;

import org.springframework.data.repository.CrudRepository;

import com.training.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

}
