package com.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.training.dal.ProductRepository;
import com.training.domain.Product;

@SpringBootApplication
public class Exercise42Application {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Exercise42Application.class, args);
//		ProductConsoleUI ui = ctx.getBean(ProductConsoleUI.class);
//		ui.createProductWithUI();
		
		ProductRepository repo = ctx.getBean(ProductRepository.class);
		Product test = new Product("test", 10001, 1);
		repo.save(test);
	}

}
