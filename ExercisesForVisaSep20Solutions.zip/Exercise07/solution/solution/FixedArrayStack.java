package solution;


public class FixedArrayStack implements Stack {

	private Object[] allElements;
	private int top = -1;
	
	public FixedArrayStack(int capacity) {
		allElements = new Object[capacity];
	}
	
	@Override
	public void push(Object anElement)  {
		try {
			allElements[++top] = anElement;
		}catch (ArrayIndexOutOfBoundsException e) {
			top--;
			throw new StackFullException();
		}
		
	}

	@Override
	public Object pop()  {
		
		return allElements[top--];
	}

}
