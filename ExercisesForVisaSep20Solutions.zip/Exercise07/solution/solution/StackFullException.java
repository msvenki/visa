package solution;

public class StackFullException extends RuntimeException {

}
