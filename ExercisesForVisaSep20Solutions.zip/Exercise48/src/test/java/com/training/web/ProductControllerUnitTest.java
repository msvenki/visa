package com.training.web;

import static org.junit.Assert.*;

import org.hamcrest.CoreMatchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.training.domain.Product;
import com.training.service.ProductService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = { ProductController.class })
public class ProductControllerUnitTest {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	ProductService service;

	@Test
	public void testGetProductById() throws Exception {

		// Arrange
		int id = 1;
		Product dataReturnedByMock = new Product("test", 10000, 5);
		dataReturnedByMock.setId(id);

		Mockito.when(service.findById(id)).thenReturn(dataReturnedByMock);
		// Act and Assert

		mockMvc.perform(MockMvcRequestBuilders.get("/products/{id}", id).accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$.id", CoreMatchers.is(id)));

	}

}
