package solution;

public class StackFullException extends RuntimeException {

	public StackFullException(Throwable cause) {
		super(cause);
		
	}

	
}
