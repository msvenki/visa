package solution;


public interface Stack {
	
	void push(Object anElement);
	Object pop();

}
