package solution;


public class StackDemo {

	public static void main(String[] args) {
		
		
		
		StackUser user = new StackUser();
		FixedArrayStack s = new FixedArrayStack(9);
		
			user.fillUp(s);
		
		System.out.println("------------------------");
		//user.empty(s);

	}

}
