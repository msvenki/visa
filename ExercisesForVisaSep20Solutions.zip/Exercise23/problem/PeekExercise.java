public class PeekExercise {

	public static void main(String[] args) {
		
		Product[] products = {
				new Product(1, "n1", 1234),
				new Product(2, "n2", 234),
				new Product(3, "n3", 5657),
				new Product(4, "n4", 501),
				new Product(5, "n5", 399),
				new Product(6, "n6", 487),
				new Product(7, "n7", 367)
		};

		

	}

}
