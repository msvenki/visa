package solution;
import java.util.HashMap;
import java.util.Map;

public class GenericMethodExercise {
	
	public static <K,V> void replaceIfExists(Map<K,V> map,K key,V value) {
		if(map.containsKey(key)) {
			map.put(key, value);
		}
	}

	public static void main(String[] args) {
		
		Map<String,String> strVsStrMap = new HashMap<>();
		Map<Integer,Double> intVsDoubleMap = new HashMap<>();
		Map<String,Integer> strVsIntMap = new HashMap<>();
		
		String aString = "something";
		Integer anInt = 10;
		Double aDouble = 10.0;
		
//		following calls should be legal
		replaceIfExists(strVsStrMap,aString,aString);
		replaceIfExists(strVsIntMap,aString,anInt);
		replaceIfExists(intVsDoubleMap,anInt,aDouble);
		
//		following calls should be illegal
//		replaceIfExists(strVsStrMap,aString,anInt);
//		replaceIfExists(strVsIntMap,aDouble,anInt);
//		replaceIfExists(intVsDoubleMap,anInt,aString);
	}

}
