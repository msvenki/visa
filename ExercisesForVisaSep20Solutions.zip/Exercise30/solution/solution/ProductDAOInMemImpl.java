package solution;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;



public class ProductDAOInMemImpl {
	
	Map<Integer,Product> db = new ConcurrentHashMap<>();
	AtomicInteger idSequence = new AtomicInteger(0);
	
	
	public Product save(Product toBeSaved) {
		int id = idSequence.incrementAndGet();
		toBeSaved.setId(id);
		db.put(id, toBeSaved);
		return toBeSaved;
	}
	
	
	public Product findById(int id) {
		
		return db.get(id);
	}
	
	
	public List<Product> findAll() {
		Collection<Product> values = db.values();
		return new ArrayList<>(values);
	}

	
	public void deleteById(int id) {
		db.remove(id);
		
	}

}
