
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class ProductDAOInMemImpl {
	
	Map<Integer,Product> db = new HashMap<>();
	int idSequence = 0;
	
	
	public Product save(Product toBeSaved) {
		int id = ++idSequence;
		toBeSaved.setId(id);
		db.put(id, toBeSaved);
		return toBeSaved;
	}
	
	
	public Product findById(int id) {
		
		return db.get(id);
	}
	
	
	public List<Product> findAll() {
		Collection<Product> values = db.values();
		return new ArrayList<>(values);
	}

	
	public void deleteById(int id) {
		db.remove(id);
		
	}

}
