package solution;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapExercise {

	public static void main(String[] args) {
		Map<ChemicalElement,Double> earthElements = new HashMap<>();
		earthElements.put(new ChemicalElement("O", 8), 46.1);
		earthElements.put(new ChemicalElement("Si", 14), 28.2);
		earthElements.put(new ChemicalElement("Al", 13), 8.3);
		earthElements.put(new ChemicalElement("Fe", 26), 5.63);
		earthElements.put(new ChemicalElement("Ca", 20), 4.15);
		earthElements.put(new ChemicalElement("Na", 11), 2.36);
		earthElements.put(new ChemicalElement("Mg", 12), 2.33);
		earthElements.put(new ChemicalElement("K", 19), 2.09);
		earthElements.put(new ChemicalElement("Ti", 22), 0.57);
		earthElements.put(new ChemicalElement("H", 1), 0.14);
		
		Scanner keyBoard = new Scanner(System.in);
		System.out.println("Enter an atomic number: ");
		int atomicNumber = Integer.parseInt(keyBoard.nextLine());
		System.out.println("Enter the symbol: ");
		String symbol = keyBoard.nextLine();
		
		ChemicalElement element = new ChemicalElement(symbol, atomicNumber);
		
		if(earthElements.containsKey(element)) {
			System.out.println("% of earth = "+earthElements.get(element));
		}else {
			System.out.println("Data not found!!");
		}

	}

}
