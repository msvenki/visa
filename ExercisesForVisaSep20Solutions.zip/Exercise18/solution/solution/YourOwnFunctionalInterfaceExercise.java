package solution;
public class YourOwnFunctionalInterfaceExercise {
	
	public static String betterString(String arg1,String arg2, TwoStringPredicate tester) {
		if(tester.isFirstBetterThanSecond(arg1, arg2)) {
			return arg1;
		}else {
			return arg2;
		}
	}

	public static void main(String[] args) {
		
		String string1 = "Hi";
		String string2 = "Hello";

		String longer = betterString(string1, string2, (s1, s2) -> s1.length() > s2.length());
		System.out.println(longer);
		String first = betterString(string1, string2, (s1, s2) -> true);
		System.out.println(first);

	}

}
