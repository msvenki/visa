public class YourOwnFunctionalInterfaceExercise {

	public static void main(String[] args) {
		

//		betterString(string1, string2, (s1, s2) -> s1.length() > s2.length());
//		betterString(string1, string2, (s1, s2) -> true);

	}

}
