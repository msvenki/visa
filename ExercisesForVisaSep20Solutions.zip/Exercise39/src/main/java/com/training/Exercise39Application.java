package com.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.training.ui.ProductConsoleUI;

@SpringBootApplication
public class Exercise39Application {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Exercise39Application.class, args);
		ProductConsoleUI ui = ctx.getBean(ProductConsoleUI.class);
		ui.createProductWithUI();
	}

}
