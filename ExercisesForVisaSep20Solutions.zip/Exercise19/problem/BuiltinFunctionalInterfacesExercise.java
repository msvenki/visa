public class BuiltinFunctionalInterfacesExercise {

	public static void main(String[] args) {
		


	}

}
