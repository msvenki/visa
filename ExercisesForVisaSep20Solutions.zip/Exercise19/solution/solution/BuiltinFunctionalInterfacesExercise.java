package solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class BuiltinFunctionalInterfacesExercise {
	
//	Part 1
//	public static List<String> allMatches(List<String> list,Predicate<String> condition){
//		List<String> result = new ArrayList<>();
//		
//		for(String anItem : list) {
//			if(condition.test(anItem)) {
//				result.add(anItem);
//			}
//		}
//		
//		return result;
//	}

//	Part 2
	public static <T> List<T> allMatches(List<T> list,Predicate<T> condition){
		List<T> result = new ArrayList<>();
		
		for(T anItem : list) {
			if(condition.test(anItem)) {
				result.add(anItem);
			}
		}
		
		return result;
	}
	
//	Part 3
	
//	public static List<String> transformedList(List<String> list,Function<String,String> transformer){
//		List<String> result = new ArrayList<>();
//		for(String anItem : list) {
//			String transformedItem = transformer.apply(anItem);
//			result.add(transformedItem);
//		}
//		return result;
//	}
	
//	Part 4
	public static <T,R> List<R> transformedList(List<T> list,Function<T,R> transformer){
		List<R> result = new ArrayList<>();
		for(T anItem : list) {
			R transformedItem = transformer.apply(anItem);
			result.add(transformedItem);
		}
		return result;
	}
	
	public static void main(String[] args) {
		
		String[] temp = {"this","is","a","small","array","of","words"};
		List<String> strings = new ArrayList<>(Arrays.asList(temp));
		List<String> shortWords = allMatches(strings, s -> s.length() < 4);
		List<String> excitingWords =transformedList(strings, s -> s + "!");
		List<Integer> wordLengths =transformedList(strings, String::length);
		System.out.println(wordLengths);
	}

}
