public class ForEachExercise {

	public static void main(String[] args) {
		


	}

}
