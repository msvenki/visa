package solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ForEachExercise {

	public static void main(String[] args) {
		String[] temp = {"this","is","a","small","array","of","words"};
		List<String> strings = new ArrayList<>(Arrays.asList(temp));

//		Part 1
		strings.forEach(s->System.out.println(s+"  "));

//		Part 2
		strings.forEach(System.out::println);
	}

}
