package solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReduceExercise1 {

	public static void main(String[] args) {
		
		String[] temp = {"this","is","a","small","arrays","of","words"};
		List<String> words = new ArrayList<>(Arrays.asList(temp));
		
		String joined = words.stream().reduce((s1,s2)-> s1+s2).get();
		
		System.out.println(joined);

	}

}
