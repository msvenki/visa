package solution;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class FlatMapExercise {

	public static void main(String[] args) {
		
		List<List<Integer>> runsInMatches = new ArrayList<>();
		runsInMatches.add(Arrays.asList(23,34,45,46));
		runsInMatches.add(Arrays.asList(76,5,55,34));
		runsInMatches.add(Arrays.asList(34,14,25,26));

		int total = runsInMatches.stream().flatMap(Collection::stream).reduce(0, (i1,i2)->i1+i2);
		System.out.println(total);
	}

}
