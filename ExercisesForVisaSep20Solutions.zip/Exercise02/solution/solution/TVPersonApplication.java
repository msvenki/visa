package solution;

public class TVPersonApplication {

	public static void main(String[] args) {
		
		Person p = new Person();
		TV4K tvObj = new TV4K();
		
		p.spendEvening(tvObj);

	}

}
