
public class TV {
	
	public void on() {
		System.out.println("Switching on TV....");
	}
	
	public void off() {
		System.out.println("Switching off TV....");
	}

}
