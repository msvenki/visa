
public class TV4K {

	public void on() {
		System.out.println("<<<<<<Switching on 4K TV....>>>>>>");
	}
	
	public void off() {
		System.out.println("<<<<<<Switching off 4K TV....>>>>>>");
	}
	
}
