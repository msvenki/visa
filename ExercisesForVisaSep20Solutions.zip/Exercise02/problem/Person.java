
public class Person {
	
	public void spendEvening(TV tvObj) {
		tvObj.on();
		
		// watch the program
		
		tvObj.off();
	}

}
