import java.util.Scanner;

public class ListExercise {

	public static void main(String[] args) {
		Scanner keyBoard = new Scanner(System.in);
		// use keyBoard.nextLine() to read from key board

	}

}
