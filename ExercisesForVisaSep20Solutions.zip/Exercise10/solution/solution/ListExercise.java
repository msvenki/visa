package solution;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListExercise {

	public static void main(String[] args) {
		Scanner keyBoard = new Scanner(System.in);
		List<String> words = new ArrayList<>();
		
		while(true) {
			System.out.println("Enter a word: ");
			String aWord = keyBoard.nextLine();
			if(words.size() >=7 && aWord.equalsIgnoreCase("quit")) {
				break;
			}
			words.add(aWord);
		}
		
		System.out.println("First element: "+words.get(0));
		System.out.println("Third element: "+words.get(2));
		System.out.println("Last element: "+words.get(words.size() - 1));
		
		System.out.println("All elements: ");
		for(String s : words) {
			System.out.println(s);
		}

	}

}
