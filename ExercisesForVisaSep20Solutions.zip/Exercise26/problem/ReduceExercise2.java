public class ReduceExercise2 {

	public static void main(String[] args) {
		


	}

}
