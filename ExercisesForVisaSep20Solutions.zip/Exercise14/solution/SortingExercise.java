import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortingExercise {

	public static void main(String[] args) {
		String[] temp = {"this","is","a","small","array","of","words"};
		List<String> strings = new ArrayList<>(Arrays.asList(temp));
		
		System.out.println("Before Sorting\n"+strings);
		Collections.sort(strings);
		System.out.println("After Sorting Alphabetically\n"+strings);
		Collections.sort(strings,new StringLengthComparator());
		System.out.println("After Sorting By Length\n"+strings);
		Collections.sort(strings,new StringEvenOddComparator());
		System.out.println("After Sorting By Even/Odd\n"+strings);
	}

}
